import React from 'react';

const table = () => {
  return (
    <div>더미</div>
  )
}

export default table;