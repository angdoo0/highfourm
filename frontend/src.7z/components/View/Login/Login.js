import React from 'react';

const login = () => {
  return (
    <div>더미</div>
  )
}

export default login;